<?php

return [
	"/web/login" => [
		"layout" => "layout-login.php",
		"view" => "Login/index.php",
	],
];