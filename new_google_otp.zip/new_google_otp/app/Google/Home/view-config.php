<?php

return [
	"/web" => [
		"layout" => "layout-main.php",
		"view" => "Home/index.php",
	],
	"/web/home" => [
		"layout" => "layout-main.php",
		"view" => "Home/index.php",
	],
];