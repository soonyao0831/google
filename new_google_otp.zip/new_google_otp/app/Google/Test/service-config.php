<?php

use App\Google\Test\Service\TestService;

return [
	"/google/test/test" => [
		"service" => TestService::class,
	],
];