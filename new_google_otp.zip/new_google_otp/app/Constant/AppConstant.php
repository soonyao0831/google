<?php
declare (strict_types = 1);

namespace App\Constant;

class AppConstant {

	public static $SESSION_EXPIRE_TIME = (30 * 60);

	public static $APP_SECRET = "";

	public static $API_KEY = "";

	public static $OTP_SESSION_KEY = "HTH36LENHZ3Y5JSBYNGCVBRIOXRNM5RU";

	public static $IMAGE_UPLOAD_DIR = "public/static/image/";

	public static $PROFILE_IMAGE_DIR = "/public/static/image/";

	public static $DEFAULT_PROFILE_IMAGE = "/public/static/image/profile_img.PNG";
}