function getFormData(data){
	return JSON.stringify(data);
}