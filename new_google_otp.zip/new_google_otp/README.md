## 1. Installation

To download Redis via https://github.com/tporadowski/redis/releases if you are window user.

Refer to https://github.com/phpredis/phpredis/blob/develop/INSTALL.markdown download and extract php_redis.dll to PATH/TO/php/ext and update php.ini to following screen below.

cd via cmd to the redis directory and enter "redis-server.exe redis.windows.conf" command.

To download and install Composer via https://getcomposer.org/download/.
